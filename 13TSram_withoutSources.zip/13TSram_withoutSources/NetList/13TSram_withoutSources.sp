* SPICE export by:  S-Edit 2019.2.0
* Export time:      Tue Apr  1 17:48:21 2025
* Design path:      C:\Users\deepa\OneDrive\Documents\TannerEDA\TannerTools_v2019.2\Process\Generic_250nm\lib.defs
* Library:          SRAM
* Cell:             13TSram_withoutSources
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "C:\Users\deepa\OneDrive\Documents\TannerEDA\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

***** Top Level *****
MMn1 QB1 B Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=1500 $y=2200 $w=400 $h=600 $m
MMn2 QB2 B Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8300 $y=2200 $w=400 $h=600
MMn3 Q QB1 Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=3000 $y=3700 $w=400 $h=600
MMn4 Q QB2 Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=6200 $y=3700 $w=400 $h=600 $m
MMn5 Q QB2 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4600 $y=2900 $w=400 $h=600 $m
MMn6 B WWL WBL Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4600 $y=1500 $w=400 $h=600 $m
MMn7 WBL WWL A Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4800 $y=6800 $w=400 $h=600 $m
MMn8 Q RWL RBL Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4800 $y=3900 $w=400 $h=600 $m
MMp1 QB1 A Vdd Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=1500 $y=6200 $w=400 $h=600 $m
MMp2 QB2 A Vdd Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8300 $y=6200 $w=400 $h=600
MMp3 Q QB1 Vdd Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=3000 $y=4800 $w=400 $h=600
MMp4 Q QB2 Vdd Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=6200 $y=4800 $w=400 $h=600 $m
MMp5 Q QB2 A Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4800 $y=5600 $w=400 $h=600 $m
VV1 Vdd Gnd  DC 50m $ $x=300 $y=6500 $w=400 $h=600
VV2 RBL Gnd  BIT({0100101111} ON=50m ) $ $x=6300 $y=1600 $w=400 $h=600
VV3 RWL Gnd  BIT({11111111110} ON=50m ) $ $x=7200 $y=1600 $w=400 $h=600
VV4 WWL Gnd  BIT({11111111110} ON=50m ) $ $x=3000 $y=1600 $w=400 $h=600
VV5 WBL Gnd  BIT({0100101111} ON=50m ) $ $x=2000 $y=1600 $w=400 $h=600

********* Simulation Settings - Analysis Section *********
.tran 10ns 400ns

********* Simulation Settings - Additional SPICE Commands *********

.end

